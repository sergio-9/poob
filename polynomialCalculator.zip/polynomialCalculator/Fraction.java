
/**
  *Fraction
  * This class implements the Fraction data type; that is, a rational number that can be written in the form p/q, where p and q are integers, with q <> 0
  * The implementation is done by immutable objects
  * INV: The fractional is represented irreducibly.
  * @author ESCUELA
  */
public class Fraction {
    public int num;
    public int den;
    public Fraction c;
     /**Calculate the greatest common divisor of two integers
     * We will implement it using the recursive algorithm
     * @param a first integer
     * @param b second integer
     * @return the Greatest Common Divisor of a and b
     */
    public  static int gcd(int a,int b){
        int menor,out = 0, x = 0;
        if(Math.abs(a) < Math.abs(b)){
            menor = a;
        }
        else{
            menor = b;
        }
        int i = Math.abs(menor);
        while(x == 0 || i < 0){
            
            if(a % i == 0 && b % i == 0 && x == 0){
                out = i;
                x = 1;
            }
            i -= 1;
        }
        return out;
        
        
    }    
    
    /**Create a new fraction, given the numerator and denominator
     * @param numerator
     * @param denominator. denominator <> 0
     */
    public Fraction (int numerator, int denominator) {
        num = numerator/gcd(numerator,denominator);
        den = denominator/gcd(numerator,denominator);
        if(den < 0){
            den = -den;
            num = -num;
        }
    }
    
    /**Create a fraction corresponding to an integer
     * @param integer the integer to create
     */
    public Fraction (int integer) {
        num = integer;
        den = 1;
    }

    /**Create a fraction, from its mixed representation.
     * The number created is mixedInteger + mixednumerator/mixeddenominator
     * @param integer the integer part of the number
     * @param numerator the numerator of the fractional part
     * @param denominator the denominator of the fractional part. denominator!=0
     */
    public Fraction (int integer, int numerator, int denominator) {
        num = numerator * denominator + integer;
        den = denominator;
        num = num/gcd(num,den);
        den = den/gcd(num,den);
        if(den < 0){
            den = -den;
            num = -num;
        }
    }

    /**
     * Return the numerator of the simplified fraction
     * A fractional p/q is written in simplified form if q is a positive integer and
     * The greatest common divisor of p and q is 1.
     * @return The numerator of the simplified fraction
     */
    public int numerator() {      
        return num;
    }
    
     /**
     * Return the denominator of the simplified fraction
     * A fractional p/q is written in simplified form if q is a positive integer and
     * The greatest common divisor of p and q is 1.
     * @return The denominator of the simplified fraction
     */   
    public int denominator() {        
        return den;
    }
    
    /**
     * Add this fraction with another fraction
     * @param other is another fractional
     * @return this+other
     */
    public Fraction sume (Fraction other) {
        this.c = c;        
        c.num = num * other.den + other.num * den;
        c.den = other.den * den;
        return c;
    }
    
    /**
     * Substract this fraction with another fraction
     * @param other is another fractional
     * @return this-other
     */
    public Fraction substract (Fraction other) {
        this.c = c;        
        c.num = num * other.den - other.num * den;
        c.den = other.den * den;
        return c;
    }   
    /**
     * Multiply this fraction with another fraction
     * @param other is another fractional
     * @return this*other
     */
    public Fraction multiply (Fraction other) {
        this.c = c;        
        c.num = num * other.num;
        c.den = other.den * den;
        return c;
    }
    
    
    /**Divide this fraction with another fraction
     * @param other is another fractional
     * @return this/other
     */
    public Fraction divide (Fraction other) {
        this.c = c;        
        c.num = num * other.den;
        c.den = other.num * den;
        return c;
    }
    
    
    @Override
    public boolean equals(Object obj) {
        return equals((Fraction)obj);
    }    
    
      /**Compare this fraction to another fraction
      * @param other eL other fractional
      * @return true if this fraction is mathematically equal to the other fraction, False d.l.c.
      */
    public boolean equals (Fraction other) {
        this.c = c;
        if(c == other){
            return true;
        }
        else{
            return false;
        }
    }


    /** Calculate the string representation of a fraction in mixed simplified format
     * @see java.lang.Object#toString(java.lang.Object)
     */
    @Override
    public String toString() {
        this.c = c;
        String numerator = num+"";
        String denominator = den+"";        
        return numerator+"/"+denominator;
    }
    
}
