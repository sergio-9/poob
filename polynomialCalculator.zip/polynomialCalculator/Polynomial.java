import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.lang.String;
/**
 * Write a description of class Polynomial here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Polynomial
{
    public Fraction fraction[];
    public int grado;
    public int x[];
    public Polynomial c;
    public ArrayList<Integer> n = new ArrayList<Integer>();
    public ArrayList<Integer> d = new ArrayList<Integer>();
    public ArrayList<Integer> p = new ArrayList<Integer>();
    public Polynomial(String polinomio){
        boolean poli = false;
        int i = 0, parentAb = 0, sigDiv = 0, parentCe = 0, equiz = 0, signo = 0, j = 0;
        String num = "", sig = "", dev = "", grado = "";        
        this.n = n;
        this.d = d;
        this.fraction = fraction;
        this.p = p;
        while(polinomio.length() > 1){
            while(poli == false){
                if(polinomio.charAt(i) == '('){
                    parentAb = i;
                }
                if(polinomio.charAt(i) == '/'){
                    sigDiv = i;
                }
                if(polinomio.charAt(i) == ')'){
                    parentCe = i;
                }
                if(polinomio.charAt(i) == 'x'){
                    equiz = i;
                }
                if(polinomio.charAt(i) == '+' || polinomio.charAt(i) == '-' || polinomio.charAt(i) == ' '){

                    if(polinomio.charAt(i) == '+'){
                        signo = i;
                    }
                    if(polinomio.charAt(i) == '-'){
                        signo = i;
                    }
                    if(polinomio.charAt(i) == ' '){
                        signo = i;
                    }
                    System.out.println(signo);                    
                    poli = true;
                }
                i += 1;
            }
            num = ""; 
            sig = ""; 
            dev = ""; 
            grado = "";
            for(i = parentAb +1 ; i < sigDiv  ; i++){
                num = num + polinomio.charAt(i) ;
            }
            for(i = sigDiv +1; i < parentCe  ; i++){
                dev = polinomio.charAt(i) + dev;
            }
            for(i = equiz +1 ; i < signo ; i++){
                grado = polinomio.charAt(i) + grado;
            }

            

            int numerador = Integer.parseInt(num);
            int denominador = Integer.parseInt(dev);
            int g = Integer.parseInt(grado);
            n.add(numerador);
            d.add(denominador);
            
            p.add(g);
            j += 1;
            if(polinomio.length() != 1){
                System.out.println(polinomio.length());
                System.out.println(signo);
                polinomio = polinomio.substring(signo+1);
            }
            System.out.println(polinomio);
            //this.grado = grado;
        }
                 
        int x[] = new int[p.size()];
        Fraction fraction[] = new Fraction[p.size()];
        this.fraction = fraction;
        this.x = x;

        for(int k = 0; i >= p.size(); i--){
            System.out.println(p.get(k));
            x[k] = p.get(k);
            fraction[k] = new Fraction(n.get(k),d.get(k));
        }
        
    }
    public void Poly(){
        grado = p.size();
        this.grado = grado;        
        int x[] = new int[grado+1];
        Fraction fraction[] = new Fraction[grado+1];
        this.fraction = fraction;
        this.x = x;
        
    }

    public void makePolinomial(){
        //this.fraction = fraction;
        for(int i = grado; i >= 0; i--){
            int numerador = Integer.parseInt(JOptionPane.showInputDialog("dijite el numerador con el grado polinomial " + i ));
            int denominador = Integer.parseInt(JOptionPane.showInputDialog("dijite el denominador con el grado polinomial " + i ));
            x[i] = i;
            fraction[i] = new Fraction(numerador,denominador);
        }
    }
    
    public void print(Polynomial c){
        for(int i = 0; i < grado+1; i++){
            System.out.print("(" + c.fraction[i] + ")x" + c.x[i]);
            if(i != grado){
                System.out.print(" + ");
            }
        }
    }
    
    public void operaciones(Polynomial a,char op, Polynomial b){
        this.c = c;
        int graMenor;
        char prelacion;
        if(a.grado < b.grado){
            graMenor = a.grado;
            prelacion = 'b';
        }
        else{
            graMenor = b.grado;
            prelacion = 'a';
        }
        switch(op){
            case '+' :
                suma(a, graMenor, b, prelacion);
                break;
            case '-' :
                resta(a, graMenor, b, prelacion);
                break;
            case '*' :
                multiplicacion(a, graMenor, b, prelacion);
                break;
            case '/' :
                division(a, graMenor, b, prelacion);
                break;
        }
        print(c);
    }
    
    public void suma(Polynomial a,int graMenor, Polynomial b,char prelacion){
        if(prelacion == 'a'){
            for(int i = 0; i <= graMenor; i++){
                    a.fraction[i] = a.fraction[i].sume(b.fraction[i]);
            }
        }
        else if(prelacion == 'b'){
             for(int i = 0; i <= graMenor; i++){
                    b.fraction[i] = b.fraction[i].sume(a.fraction[i]);
             }            
        }    
        c = b;
        this.c = c;
    }
    
    public void resta(Polynomial a,int graMenor, Polynomial b,char prelacion){
        if(prelacion == 'a'){
            for(int i = 0; i <= graMenor; i++){
                    a.fraction[i] = a.fraction[i].substract(b.fraction[i]);
            }
        }
        else if(prelacion == 'b'){
             for(int i = 0; i <= graMenor; i++){
                    b.fraction[i] = b.fraction[i].substract(a.fraction[i]);
             }            
        }    
        c = b;
        this.c = c;
    }    
    
    public void multiplicacion(Polynomial a,int graMenor, Polynomial b,char prelacion){
        if(prelacion == 'a'){
            for(int i = 0; i <= graMenor; i++){
                    a.fraction[i] = a.fraction[i].multiply(b.fraction[i]);
            }
        }
        else if(prelacion == 'b'){
             for(int i = 0; i <= graMenor; i++){
                    b.fraction[i] = b.fraction[i].multiply(a.fraction[i]);
             }            
        }    
        c = b;
        this.c = c;
    } 
    
    public void division(Polynomial a,int graMenor, Polynomial b,char prelacion){
        if(prelacion == 'a'){
            for(int i = 0; i <= graMenor; i++){
                    a.fraction[i] = a.fraction[i].divide(b.fraction[i]);
            }
        }
        else if(prelacion == 'b'){
             for(int i = 0; i <= graMenor; i++){
                    b.fraction[i] = b.fraction[i].divide(a.fraction[i]);
             }            
        }    
        c = b;
        this.c = c;
    }
}
